from collections import Counter
from dataclasses import dataclass, field
from typing import Optional

import pandas as pd

import port.api.props as props

#: Largest part of a donation, in bytes. The consent page writes the donation in
#: parts of at most this size and each part is sent as its own request, so the
#: whole donation never exists in one piece in the browser (Eyra review R01/R02).
#: 25 MB was measured to keep donating flat on an 8 GB laptop and is far below
#: Next's 210 MB request limit.
DONATE_PART_BYTES = 25_000_000

@dataclass
class PropsUIPromptConsentFormTableViz:
    """
    Table to be shown to the participant prior to donation.

    Attributes:
        id (str): A unique string to identify the table after donation.
        title (Translatable): Title of the table.
        data_frame (pd.DataFrame | Dict[str, Dict[str, Any]]): Table to be shown can be a pandas DataFrame or a dictionary.
        description (Optional[Translatable]): Optional description of the table.
        visualizations (Optional[list]): Optional visualizations to be shown.
        folded (Optional[bool]): Whether the table should be initially folded.
        delete_option (Optional[bool]): Whether to show a delete option for the table.
        extraction_errors (dict[str, int]): Error counts from extracting this table, e.g. skipped
            messages. Donated with the table as "extraction errors" (Eyra review R03).

    Examples::

        data_frame_df = pd.DataFrame([
            {"column1": 1, "column2": 4},
            {"column1": 2, "column2": 5},
            {"column1": 3, "column2": 6},
        ])

        example1 = PropsUIPromptConsentFormTableViz(
            id="example1",
            title=props.Translatable({
                "en": "Table as DataFrame",
                "nl": "Tabel als DataFrame",
            }),
            data_frame=data_frame_df,
        )

        data_frame_dict = {
            "column1": {"0": 1, "1": 4},
            "column2": {"0": 2, "1": 5},
            "column3": {"0": 3, "1": 6},
        }

        example2 = PropsUIPromptConsentFormTableViz(
            id="example2",
            title=props.Translatable({
                "en": "Table as Dictionary",
                "nl": "Tabel als woordenboek",
            }),
            data_frame=data_frame_dict,
        )
    """
    id: str
    title: props.Translatable
    data_frame: pd.DataFrame
    description: Optional[props.Translatable] = None
    visualizations: Optional[list] = None
    headers: Optional[dict[str, props.Translatable]] = None
    folded: Optional[bool] = False
    delete_option: Optional[bool] = True
    extraction_errors: dict[str, int] = field(default_factory=dict)

    def translate_data_frame(self):
        # UTF-8 bytes rather than a str: toJs turns bytes into a standalone
        # Uint8Array whose buffer py_worker.js *transfers* to the page, instead
        # of converting a large JS string and structured-cloning it (a copy in
        # the worker plus one per clone side). The page decodes it in
        # loadDataFrame (consent_form_viz.tsx).
        if isinstance(self.data_frame, pd.DataFrame):
            return self.data_frame.to_json().encode("utf-8")
        else:
            return self.data_frame

    def toDict(self):
        """
        Convert the object to a dictionary.

        Returns:
            dict: A dictionary representation of the object.
        """
        dict = {}
        dict["__type__"] = "PropsUIPromptConsentFormTableViz"
        dict["id"] = self.id
        dict["title"] = self.title.toDict()
        dict["data_frame"] = self.translate_data_frame()
        dict["description"] = self.description.toDict() if self.description else None
        dict["visualizations"] = self.visualizations if self.visualizations else None
        if self.headers:
            dict["headers"] = {key: value.toDict() for key, value in self.headers.items()}
        dict["folded"] = self.folded
        dict["delete_option"] = self.delete_option
        dict["extraction_errors"] = {key: int(n) for key, n in self.extraction_errors.items()}
        return dict


@dataclass
class PropsUIPromptConsentFormViz:
    """
    Tables to be shown to the participant prior to donation.

    Attributes:
        id (str): will be used as part of the filename when the data is stored
        tables (list[PropsUIPromptConsentFormTable]): A list of tables.
        description (Optional[Translatable]): Optional description of the consent form.
        donate_question (Optional[Translatable]): Optional donation question.
        donate_button (Optional[Translatable]): Optional text for the donate button.
        notice (Optional[Translatable]): Optional highlighted notice, e.g. that some data could not be read.
        donate_part_bytes (int): Largest donation part in bytes (see DONATE_PART_BYTES).
    """
    tables: list[PropsUIPromptConsentFormTableViz]
    description: Optional[props.Translatable] = None
    donate_question: Optional[props.Translatable] = None
    donate_button: Optional[props.Translatable] = None
    notice: Optional[props.Translatable] = None
    donate_part_bytes: int = DONATE_PART_BYTES

    def translate_tables(self):
        """
        Translate the tables to a list of dictionaries.

        Returns:
            list: A list of dictionaries representing the tables.
        """
        output = []
        for table in self.tables:
            output.append(table.toDict())
        return output

    def toDict(self):
        """
        Convert the object to a dictionary.

        Returns:
            dict: A dictionary representation of the object.
        """
        dict = {}
        dict["__type__"] = "PropsUIPromptConsentFormViz"
        dict["tables"] = self.translate_tables()
        dict["description"] = self.description and self.description.toDict()
        dict["donateQuestion"] = self.donate_question and self.donate_question.toDict()
        dict["donateButton"] = self.donate_button and self.donate_button.toDict()
        dict["notice"] = self.notice and self.notice.toDict()
        dict["donatePartBytes"] = self.donate_part_bytes
        return dict


@dataclass
class PropsUIPromptFileInputMultiple:
    """
    Prompt the user to submit multiple files.

    Attributes:
        description (Translatable): Text with an explanation.
        extensions (str): Accepted mime types, example: "application/zip, text/plain".
        example (Optional[Translatable]): Optional example placeholder text (e.g. sample
            filenames) shown in the file list before any file is selected. When absent,
            the component falls back to its own built-in per-locale placeholder copy.
    """
    description: props.Translatable
    extensions: str
    example: Optional[props.Translatable] = None

    def toDict(self):
        """
        Convert the object to a dictionary.

        Returns:
            dict: A dictionary representation of the object.
        """
        dict = {}
        dict["__type__"] = "PropsUIPromptFileInputMultiple"
        dict["description"] = self.description.toDict()
        dict["extensions"] = self.extensions
        if self.example is not None:
            dict["example"] = self.example.toDict()
        return dict


@dataclass
class PropsUIQuestionOpen:
    """
    Open-ended question.

    Attributes:
        id (int): Question ID.
        question (Translatable): The question text.
    """
    id: int
    question: props.Translatable

    def toDict(self):
        """
        Convert the object to a dictionary.

        Returns:
            dict: A dictionary representation of the object.
        """
        dict = {}
        dict["__type__"] = "PropsUIQuestionOpen"
        dict["id"] = self.id
        dict["question"] = self.question.toDict()
        return dict


@dataclass
class PropsUIQuestionMultipleChoiceCheckbox:
    """
    Multiple choice question with checkboxes.

    Attributes:
        id (int): Question ID.
        question (Translatable): The question text.
        choices (list[Translatable]): List of choices.
    """
    id: int
    question: props.Translatable
    choices: list[props.Translatable]

    def toDict(self):
        """
        Convert the object to a dictionary.

        Returns:
            dict: A dictionary representation of the object.
        """
        dict = {}
        dict["__type__"] = "PropsUIQuestionMultipleChoiceCheckbox"
        dict["id"] = self.id
        dict["question"] = self.question.toDict()
        dict["choices"] = [c.toDict() for c in self.choices]
        return dict


@dataclass
class PropsUIQuestionMultipleChoice:
    """
    Multiple choice question with radio buttons.

    Attributes:
        id (int): Question ID.
        question (Translatable): The question text.
        choices (list[Translatable]): List of choices.
    """
    id: int
    question: props.Translatable
    choices: list[props.Translatable]

    def toDict(self):
        """
        Convert the object to a dictionary.

        Returns:
            dict: A dictionary representation of the object.
        """
        dict = {}
        dict["__type__"] = "PropsUIQuestionMultipleChoice"
        dict["id"] = self.id
        dict["question"] = self.question.toDict()
        dict["choices"] = [c.toDict() for c in self.choices]
        return dict


@dataclass
class PropsUIPromptQuestionnaire:
    """
    Questionnaire containing multiple questions.

    Attributes:
        description (Translatable): Description of the questionnaire.
        questions (list[PropsUIQuestionMultipleChoice | PropsUIQuestionMultipleChoiceCheckbox | PropsUIQuestionOpen]):
            List of questions in the questionnaire.
    """
    description: props.Translatable
    questions: list[
        PropsUIQuestionMultipleChoice | 
        PropsUIQuestionMultipleChoiceCheckbox | 
        PropsUIQuestionOpen
    ]

    def toDict(self):
        """
        Convert the object to a dictionary.

        Returns:
            dict: A dictionary representation of the object.
        """
        dict = {}
        dict["__type__"] = "PropsUIPromptQuestionnaire"
        dict["description"] = self.description.toDict()
        dict["questions"] = [q.toDict() for q in self.questions]
        return dict


@dataclass
class PropsUIPromptRetry:
    """Retry submitting a file page

    Prompt the user if they want to submit a new file.
    This can be used in case a file could not be processed.

    Attributes:
        text: message to display
        ok: message to display if the user wants to try again
    """

    text: props.Translatable
    ok: props.Translatable

    def toDict(self):
        dict = {}
        dict["__type__"] = "PropsUIPromptRetry"
        dict["text"] = self.text.toDict()
        dict["ok"] = self.ok.toDict()
        return dict


@dataclass
class PropsUIPromptTechnicalDetails:
    """Collapsed section with technical details, such as a traceback.

    Keeps diagnostics off the participant-facing message while letting the
    participant open and read them, e.g. before deciding whether to send an
    error report that contains them (ADR-0022).

    Attributes:
        summary: label of the collapsed section
        details: preformatted text shown when the section is opened
    """

    summary: props.Translatable
    details: str

    def toDict(self):
        dict = {}
        dict["__type__"] = "PropsUIPromptTechnicalDetails"
        dict["summary"] = self.summary.toDict()
        dict["details"] = self.details
        return dict


@dataclass
class PropsUIPromptProgress:
    """Message shown while the flow works, e.g. sends a donation in parts.

    The page answers with PayloadVoid as soon as it is shown, so the flow can
    carry on (donate the next part) while the message stays on screen until
    the next render.

    Attributes:
        text: message to display
    """

    text: props.Translatable

    def toDict(self):
        dict = {}
        dict["__type__"] = "PropsUIPromptProgress"
        dict["text"] = self.text.toDict()
        return dict


@dataclass
class ExtractionResult:
    """Result of a platform extraction: tables for consent + aggregated error counts.

    The errors Counter contains type-name keys (e.g. Counter({"FileNotFoundInZipError": 3})).
    These counts are safe to forward via the bridge logger. Raw exception messages
    are never included — they stay in local __name__ logger output only.
    """
    tables: list[PropsUIPromptConsentFormTableViz]
    errors: Counter = field(default_factory=Counter)
