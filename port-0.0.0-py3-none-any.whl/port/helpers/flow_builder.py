"""FlowBuilder — shared per-platform donation flow orchestration.

Subclass this to implement a platform-specific donation flow.
Override validate_file() and extract_data(). Call start_flow()
as a generator from script.py via `yield from`.
"""
from abc import abstractmethod
from collections.abc import Generator
import gc
import json
import logging
from typing import cast
import zipfile

import port.api.props as props
import port.api.d3i_props as d3i_props
from port.api.file_utils import SeekableBinaryReader
import port.helpers.port_helpers as ph
import port.helpers.size_cap as size_cap
import port.helpers.validate as validate
import port.helpers.uploads as uploads
from port.helpers.archive_set import ArchiveSet

logger = logging.getLogger(__name__)


class TaskIncompleteError(Exception):
    """Flow ended without completion. ScriptWrapper maps this to a nonzero
    exit command so the host keeps the task pending (never completed).

    Raised with a reason key only: the fixed (code, info) pair comes from
    EXITS, so a raise site can never put exception or participant text on
    the bridge — exit info crosses it unconsented (ADR-0022/0023). Codes
    are a fork-local convention pending an agreed exit-code contract with
    Eyra; the host only distinguishes 0 from nonzero today (see ADR-0039).
    """

    EXITS = {
        "abandoned": (2, "Participant abandoned the task"),
        "donation_failed": (3, "Donation delivery failed"),
        "upload_rejected": (4, "Upload rejected"),
    }

    def __init__(self, reason: str):
        exit_code, exit_info = self.EXITS[reason]
        super().__init__(exit_info)
        self.reason = reason
        self.exit_code = exit_code
        self.exit_info = exit_info




class FlowBuilder:
    # Subclasses handling a Google-Takeout-style chunked export set this to
    # "PayloadFiles"; the file prompt, safety check, and archive-set
    # construction below key off this attribute. See ADR-0040 (ArchiveSet).
    expected_file_payload: str = "PayloadFile"

    def __init__(self, session_id: str, platform_name: str):
        self.session_id = session_id
        self.platform_name = platform_name
        self._initialize_ui_text()

    def _initialize_ui_text(self):
        """Initialize UI text based on platform name."""
        self.UI_TEXT = {
            "submit_file_header": props.Translatable({
                "en": f"Select your {self.platform_name} file",
                "nl": f"Selecteer je {self.platform_name} bestand",
                "de": f"Wählen Sie Ihre {self.platform_name}-Datei aus",
                "it": f"Selezioni il suo file di {self.platform_name}",
                "es": f"Seleccione su archivo de {self.platform_name}",
            }),
            "review_data_header": props.Translatable({
                "en": f"Inspect your {self.platform_name} data",
                "nl": f"Inspecteer je {self.platform_name} gegevens",
                "de": f"Überprüfen Sie Ihre {self.platform_name}-Daten",
                "it": f"Esamini i suoi dati di {self.platform_name}",
                "es": f"Revise sus datos de {self.platform_name}",
            }),
            "unreadable_header": props.Translatable({
                "en": "File could not be read",
                "nl": "Bestand kon niet worden gelezen",
                "de": "Datei konnte nicht gelesen werden",
                "it": "Impossibile leggere il file",
                "es": "No se ha podido leer el archivo",
            }),
            "retry_header": props.Translatable({
                "en": "Try again",
                "nl": "Probeer opnieuw",
                "de": "Erneut versuchen",
                "it": "Riprova",
                "es": "Intentar de nuevo",
            }),
            "review_data_description": props.Translatable({
                "en": f"Here you find the {self.platform_name} data from your archive that are selected for donation. Please review these data before donating them for research.",
                "nl": f"Hier vind je de {self.platform_name} gegevens uit je archief die zijn geselecteerd voor donatie. Bekijk deze gegevens alsjeblieft voordat je ze doneert voor onderzoek.",
                "de": f"Hier finden Sie die {self.platform_name}-Daten aus Ihrem Archiv, die für die Datenspende ausgewählt wurden. Bitte überprüfen Sie diese Daten, bevor Sie sie für die Forschung spenden.",
                "it": f"Qui trova i dati di {self.platform_name} del suo archivio selezionati per la donazione. La preghiamo di esaminare questi dati prima di donarli per la ricerca.",
                "es": f"Aquí encontrará los datos de {self.platform_name} de su archivo seleccionados para la donación. Por favor, revise estos datos antes de donarlos para la investigación.",
            }),
        }

    def start_flow(self):
        """Main per-platform flow: file→materialize→safety→validate→retry→extract→consent→donate.

        This is a generator. script.py calls it via `yield from flow.start_flow()`.
        Control flow rules:
        - continue: retry upload only
        - break: successful extraction, proceed to consent
        - return: terminal paths that ARE completions (exit 0 at the host)
        - raise TaskIncompleteError: terminal paths that are NOT completions —
          ScriptWrapper shows the task-incomplete page and exits nonzero so
          the host keeps the task pending (ADR-0039)

        Flow milestones are sent to the host via explicit CommandSystemLog yields
        (through emit_log). These must be PII-free. Local logger keeps full
        diagnostic detail in browser console only.
        """
        while True:
            # 1. Render file prompt → receive payload
            logger.info("Prompt for file for %s", self.platform_name)
            file_prompt = self.generate_file_prompt()
            yield from ph.emit_log("info", f"[{self.platform_name}] Upload prompt sent")
            file_result = yield ph.render_page(self.UI_TEXT["submit_file_header"], file_prompt)

            # Skip: the established participant-declined shapes. These
            # are pinned by ADR-0026 (PayloadString retirement) and stay
            # silent — no protocol-error page for a legitimate skip.
            # Anything else that isn't the type this flow expects is a
            # genuine protocol mismatch (version skew), not a skip, and
            # gets a visible error page instead — see the docstring above
            # `expected_file_payload`.
            if file_result.__type__ == self.expected_file_payload:
                pass
            elif file_result.__type__ in ("PayloadFalse", "PayloadVoid", "PayloadString"):
                logger.info("Skipped at file selection for %s", self.platform_name)
                yield from ph.emit_log(
                    "info",
                    f"[{self.platform_name}] Upload skipped: type={file_result.__type__}",
                )
                raise TaskIncompleteError("abandoned")
            else:
                logger.info(
                    "Protocol mismatch for %s: expected=%s got=%s",
                    self.platform_name,
                    self.expected_file_payload,
                    file_result.__type__,
                )
                yield from ph.emit_log(
                    "info",
                    f"[{self.platform_name}] Protocol mismatch: expected={self.expected_file_payload} got={file_result.__type__}",
                )
                _ = yield ph.render_protocol_error_page(self.platform_name)
                # Nothing usable arrived, so nothing can be donated: the
                # payload is rejected and the run must not exit 0 (ADR-0039).
                raise TaskIncompleteError("upload_rejected")

            is_multi = self.expected_file_payload == "PayloadFiles"

            if is_multi:
                # A PayloadFiles set — file_result.value is a list of
                # AsyncFileAdapters, one per uploaded part. Never
                # materialized. See ADR-0026/ADR-0040.
                parts = file_result.value
                total_size = sum(p.size for p in parts)
                yield from ph.emit_log(
                    "info",
                    f"[{self.platform_name}] Upload received: files={len(parts)} total_size={total_size}",
                )
            else:
                # AsyncFileAdapter — file-like, passed directly to validators
                # and extractors. Never materialized to a path. See ADR-0026.
                archive = file_result.value
                yield from ph.emit_log(
                    "info",
                    f"[{self.platform_name}] Upload received: size={archive.size}",
                )

            # 2. Safety check (size only — uses JS metadata, no read)
            try:
                uploads.check_payload_size(file_result)
            except (uploads.FileTooLargeError, uploads.TooManyFilesError) as e:
                logger.error("Safety check failed for %s: %s", self.platform_name, e)
                yield from ph.emit_log("info", f"[{self.platform_name}] Safety check failed: {type(e).__name__}")
                _ = yield ph.render_safety_error_page(self.platform_name, e)
                raise TaskIncompleteError("upload_rejected")

            if is_multi:
                # Build the union archive-set from the uploaded parts. A
                # corrupt/unreadable part surfaces here as zipfile.BadZipFile
                # (ADR-0040) — route it through the existing retry-prompt
                # path rather than a traceback, same as an invalid single
                # file failing DDP validation below.
                try:
                    archive = ArchiveSet(parts)
                except zipfile.BadZipFile:
                    logger.info("Corrupt part in %s upload; prompting retry", self.platform_name)
                    if (yield from self._prompt_retry()):
                        continue  # loop back to step 1
                    yield from ph.emit_log("info", f"[{self.platform_name}] Retry declined")
                    raise TaskIncompleteError("abandoned")

            # 3. Validate
            # `archive` is a SeekableBinaryReader for a PayloadFile flow, or
            # an ArchiveSet for a PayloadFiles flow — see the base
            # validate_file()/extract_data() docstrings. The cast keeps the
            # common single-file platforms' unannotated overrides typed
            # against the narrower, far more common SeekableBinaryReader;
            # a PayloadFiles subclass narrows its own override to ArchiveSet.
            validation = self.validate_file(cast(SeekableBinaryReader, archive))
            status = validation.get_status_code_id()
            category = getattr(validation, "current_ddp_category", None)
            category_id = getattr(category, "id", "unknown") if category else "unknown"

            if status == 0:
                yield from ph.emit_log("info", f"[{self.platform_name}] Validation: valid ({category_id})")
            else:
                yield from ph.emit_log("info", f"[{self.platform_name}] Validation: invalid")

            # 4. If invalid → retry prompt
            if status != 0:
                logger.info("Invalid %s file; prompting retry", self.platform_name)
                if (yield from self._prompt_retry()):
                    continue  # loop back to step 1
                yield from ph.emit_log("info", f"[{self.platform_name}] Retry declined")
                raise TaskIncompleteError("abandoned")

            # 5. Extract
            logger.info("Extracting data for %s", self.platform_name)
            raw_result = self.extract_data(cast(SeekableBinaryReader, archive), validation)
            if isinstance(raw_result, Generator):
                result = yield from raw_result
            else:
                result = raw_result

            # 6. Log extraction summary (PII-free: counts only)
            total_rows = sum(len(t.data_frame) for t in result.tables)
            if result.errors:
                error_summary = ", ".join(f"{k}×{v}" for k, v in result.errors.items())
                yield from ph.emit_log("info", f"[{self.platform_name}] Extraction complete: {len(result.tables)} tables, {total_rows} rows; errors: {error_summary}")
            else:
                yield from ph.emit_log("info", f"[{self.platform_name}] Extraction complete: {len(result.tables)} tables, {total_rows} rows; errors: none")

            # 7. If no tables → no-data page (clean empties only: zero tables
            # WITH extraction errors means the file could not be read, never
            # "no data found" — the no-data/extraction-bug separation in
            # ADR-0019). An unreadable file gets its own retry page so the
            # participant can choose another file; the error counts already
            # went to the host in the PII-free summary above.
            if not result.tables:
                if result.errors:
                    logger.info("Unreadable %s file; prompting retry", self.platform_name)
                    # Running out of memory is not a damaged file (Eyra review R01).
                    out_of_memory = result.errors.get("MemoryError", 0) > 0
                    del result, raw_result
                    if out_of_memory:
                        prompt, header = ph.generate_too_large_prompt(self.platform_name), ph.TOO_LARGE_HEADER
                    else:
                        prompt, header = self.generate_unreadable_file_prompt(), self.UI_TEXT["unreadable_header"]
                    if (yield from self._prompt_retry(prompt, header)):
                        continue  # loop back to step 1
                    yield from ph.emit_log("info", f"[{self.platform_name}] Retry declined")
                    raise TaskIncompleteError("abandoned")
                logger.info("No data extracted for %s", self.platform_name)
                _ = yield ph.render_no_data_page(self.platform_name)
                return

            break  # proceed to consent

        # 8. Render consent form
        yield from ph.emit_log("info", f"[{self.platform_name}] Consent form shown")
        review_prompt = self.generate_review_data_prompt(result.tables)
        # Tell the participant before review what could not be read (Eyra
        # review R03); the same counts are donated with each table.
        large = size_cap.estimated_donation_bytes(result.tables) >= ph.LARGE_DONATION_FRACTION * size_cap.donation_budget_bytes()
        review_prompt.notice = ph.review_notice(result.errors, large_donation=large)
        review_page = [ph.render_page(self.UI_TEXT["review_data_header"], review_prompt)]
        del review_prompt  # only review_page may reference the tables (see below)
        # Hold no reference to the extracted tables while suspended here: the
        # donation arrives as this yield's value and is allocated in Pyodide's
        # memory, which never shrinks, so free the tables first and let it
        # reuse their space. The page has its own copy; nothing below reads them.
        del result, raw_result
        gc.collect()
        consent_result = yield review_page.pop()

        # 9. Donate with per-platform key
        if consent_result.__type__ == "PayloadJSON":
            # A str, or the JsProxy of the UTF-8 bytes the consent-viz page donates.
            # The bytes are never converted here: they go back to the page as the
            # same JS object, and Pyodide's str conversions of a large donation cost
            # hundreds of MB (ADR-0046).
            reviewed_data = consent_result.value
            yield from ph.emit_log("info", f"[{self.platform_name}] Consent: accepted")
        elif consent_result.__type__ == "PayloadFalse":
            reviewed_data = json.dumps({"status": "data_submission declined"})
            yield from ph.emit_log("info", f"[{self.platform_name}] Consent: declined")
        else:
            return

        donate_key = f"{self.session_id}-{self.platform_name.lower()}"
        is_decline = consent_result.__type__ == "PayloadFalse"
        # The reviewed data is sent in parts of at most DONATE_PART_BYTES (the consent
        # page writes them; anything else is split here), each under its own key
        # (<key>_part<i>of<n>); a single part keeps the plain key. Concatenated in
        # part order they are exactly the donation.
        if is_decline:
            total, parts = 1, iter([reviewed_data])
        else:
            total, parts = ph.donation_parts(reviewed_data)
        size = ph.donation_size(reviewed_data)
        del reviewed_data  # each part is released once it has been sent
        yield from ph.emit_log("info", f"[{self.platform_name}] Donation started: payload size={size} bytes, parts={total}")
        for part, chunk in enumerate(parts, start=1):
            key = ph.donation_part_key(donate_key, part, total)
            if not is_decline:
                _ = yield ph.render_donation_progress_page(self.platform_name, part, total)
            attempt = 0
            while True:
                attempt += 1
                # A copy goes out; the part stays here until the host confirms it.
                donate_result = yield ph.donate(key, ph.sendable_copy(chunk))
                # 11. Inspect donate result
                if ph.handle_donate_result(donate_result):
                    break
                # For declines, don't show failure UI — the participant chose not to donate,
                # so a failure to record that decision is invisible infrastructure, not their problem.
                if is_decline:
                    logger.warning("Decline status donation failed for %s (silent)", self.platform_name)
                    yield from ph.emit_log("info", f"[{self.platform_name}] Donation result: decline record failed (silent)")
                    return
                logger.error("Donation failed for %s (part %d of %d, attempt %d)", self.platform_name, part, total, attempt)
                yield from ph.emit_log("info", f"[{self.platform_name}] Donation part {part} of {total}: failed (attempt {attempt})")
                if attempt == 1:
                    continue  # one automatic retry, for a brief network problem
                # Then the participant decides: try this part again, or stop.
                choice = yield ph.render_donation_retry_page(self.platform_name, part, total)
                if getattr(choice, "__type__", None) == "PayloadTrue":
                    _ = yield ph.render_donation_progress_page(self.platform_name, part, total)
                    continue
                yield from ph.emit_log("info", f"[{self.platform_name}] Donation result: failed at part {part} of {total}")
                _ = yield ph.render_donate_failure_page(self.platform_name)
                raise TaskIncompleteError("donation_failed")
            del chunk
            if total > 1:
                yield from ph.emit_log("info", f"[{self.platform_name}] Donation part {part} of {total}: success")

        yield from ph.emit_log("info", f"[{self.platform_name}] Donation result: success")

    def _prompt_retry(self, prompt=None, header=None):
        """Render a retry prompt and report the participant's choice.

        Generator helper: `yield from` it to get back True (retry — caller
        should `continue`) or False (declined — caller should raise
        TaskIncompleteError("abandoned"), since a declined retry is not a
        completion; ADR-0039). Shared by the invalid-file path and the
        corrupt-archive-set path, which both fall back to the default retry
        UI, and by the unreadable-file path, which passes its own prompt and
        header.
        """
        retry_prompt = prompt if prompt is not None else self.generate_retry_prompt()
        retry_header = header if header is not None else self.UI_TEXT["retry_header"]
        retry_result = yield ph.render_page(retry_header, retry_prompt)
        return retry_result.__type__ == "PayloadTrue"

    # Methods to be overridden by platform-specific implementations
    def generate_file_prompt(self):
        """Generate platform-specific file prompt."""
        return ph.generate_file_prompt(
            "application/zip", multiple=self.expected_file_payload == "PayloadFiles"
        )

    @abstractmethod
    def validate_file(self, file: SeekableBinaryReader) -> validate.ValidateInput:
        """Validate the file according to platform-specific rules.

        `file` is the `AsyncFileAdapter` wrapping the browser upload — a
        seekable binary reader, never a path — for the default single-file
        flow (`expected_file_payload == "PayloadFile"`). A subclass that
        sets `expected_file_payload = "PayloadFiles"` receives the unioned
        `ArchiveSet` over all uploaded parts here instead (ADR-0040); such a
        subclass should narrow this annotation locally to `ArchiveSet`.
        """
        raise NotImplementedError("Must be implemented by subclass")

    @abstractmethod
    def extract_data(self, file: SeekableBinaryReader, validation: validate.ValidateInput) -> d3i_props.ExtractionResult:
        """Extract data from file using platform-specific logic.

        `file` is the `AsyncFileAdapter` wrapping the browser upload — a
        seekable binary reader, never a path — for the default single-file
        flow (`expected_file_payload == "PayloadFile"`). A subclass that
        sets `expected_file_payload = "PayloadFiles"` receives the unioned
        `ArchiveSet` over all uploaded parts here instead (ADR-0040); such a
        subclass should narrow this annotation locally to `ArchiveSet`.
        """
        raise NotImplementedError("Must be implemented by subclass")

    def generate_retry_prompt(self):
        """Generate platform-specific retry prompt.

        Mirrors generate_file_prompt's `multiple=` flag: a PayloadFiles
        flow (expected_file_payload == "PayloadFiles") gets the multi-aware
        copy telling the participant to select ALL the files again.
        """
        return ph.generate_retry_prompt(
            self.platform_name, multiple=self.expected_file_payload == "PayloadFiles"
        )

    def generate_unreadable_file_prompt(self):
        """Generate the prompt for a file that could not be read (zero tables
        with extraction errors). Mirrors generate_retry_prompt's `multiple=`."""
        return ph.generate_unreadable_file_prompt(
            self.platform_name, multiple=self.expected_file_payload == "PayloadFiles"
        )

    def generate_review_data_prompt(self, table_list):
        """Generate platform-specific review data prompt."""
        return ph.generate_review_data_prompt(
            description=self.UI_TEXT["review_data_description"],
            table_list=table_list,
        )
